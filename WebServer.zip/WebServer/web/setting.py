DEBUG = True
DB_NAME = "lijiakui_web"
DB_HOST = '192.168.111.5:27011'
CACHE_HOST = '192.168.111.5:6371'
PORT = 9092
ACTION_DIR = ('testweb','logic')
LOCAL_URL = 'http://t-lijiakui.thunics.org'