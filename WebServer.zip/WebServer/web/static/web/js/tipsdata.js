var tipsdata={
	"tipa":"hfhfhfhfhfh",
            "tipb":"hfhfhf年后hfhfh",
             "pt":'风机温度'
     }
