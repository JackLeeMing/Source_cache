/**
 *  JS 实用工具集, Plotly 的一些常用配置和设置
 *  author comger@gmail.com
 */

//整个工具栏不显示
var plot_config_null ={ modeBarButtonsToRemove:['sendDataToCloud','autoScale2d','select2d','lasso2d','hoverCompareCartesian'],
                        displaylogo: false, displayModeBar: false, showLink:false};