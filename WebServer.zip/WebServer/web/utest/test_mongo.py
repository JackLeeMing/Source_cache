# -*- coding:utf-8 -*-
"""
    author comger@gmail.com
"""
import json
from kpages import LogicContext, reflesh_config
from unittest import TestCase


class DemoCase(TestCase):
    def setUp(self):
        pass

    def test_print(self):
        pass


class Demo1Case(TestCase):
    def setUp(self):
        pass

    def test_insert(self):
        pass
